1- Set the mysql connection string in the following file, line 37:

Backend/Persistence/Context/MySqlDbContext.cs


2- Run following commands:

cd Backend
dotnet ef database update
dotnet run


3- Open the following page:

Front/Login.html


4- Enter a username (no registeration needed)
5- Test your user stories.
